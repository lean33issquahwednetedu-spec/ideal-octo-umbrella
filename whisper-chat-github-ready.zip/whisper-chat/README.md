# Whisper — Private Real-Time Chat

A small two-person messaging web app built with HTML, CSS, JavaScript, Firebase Authentication, and Cloud Firestore.

## Features

- Email/password account creation and sign-in
- Unique usernames (3–20 letters, numbers, underscores)
- Find another user by exact username
- Real-time messages and conversation list
- Firestore Security Rules limit chat and message access to conversation members
- Responsive layout for desktop and mobile

## Before you start

Create a Firebase project at https://console.firebase.google.com/.

1. Add a **Web app** to the Firebase project and copy its Firebase configuration.
2. In **Authentication → Sign-in method**, enable **Email/Password**.
3. In **Firestore Database**, create a database.
4. Open `index.html` and replace the four `PASTE_YOUR_...` values in `firebaseConfig` with the values from your Firebase web app.
5. In Firestore **Rules**, publish the contents of `firestore.rules`. Or use the Firebase CLI deployment instructions below.
6. For local testing, use a local server (not a `file://` URL). For example, if Python is installed, run `python -m http.server 8000` in this folder and open http://localhost:8000.

Firebase web config values identify your Firebase project; they are not server credentials. Do not put service-account private keys or Admin SDK credentials in frontend code.

## Test with two people

1. Open the app in two separate browsers or browser profiles.
2. Create two accounts with different emails and different usernames.
3. In account A, search for account B's exact username and start a conversation.
4. Send a message. It should appear live in both windows.
5. Try signing out and back in; the conversation should remain available.

## Deploy with Firebase Hosting

Install Node.js first, then run:

```bash
npm install -g firebase-tools
firebase login
firebase init hosting firestore
```

When prompted:
- Select the Firebase project you created.
- Use `.` as the public directory (the `firebase.json` in this repository is already configured for this).
- Configure as a single-page app: **No**.
- If asked to overwrite `firebase.json` or `firestore.rules`, choose **No** to preserve these files.

Then deploy:

```bash
firebase deploy --only hosting,firestore:rules
```

The CLI prints your hosted URL, usually `https://YOUR_PROJECT_ID.web.app`.

## GitHub

1. Create a GitHub repository, for example `whisper-chat`.
2. Upload `index.html`, `firestore.rules`, `firebase.json`, `.gitignore`, and `README.md`.
3. Commit the files.

### Should I use GitHub Pages?

GitHub Pages can host static files, but it does not enforce Firestore rules or provide the backend. The app can use Firebase from GitHub Pages after Firebase is configured, but Firebase Hosting is the simplest route because this repository already includes `firebase.json` and the Firebase CLI can deploy both the site and Firestore rules.

If using GitHub Pages, publish the repository's root folder in Settings → Pages. You must separately publish `firestore.rules` to Firebase; merely committing the rules file to GitHub does not make Firebase enforce them.

## Security and limitations

- Firestore rules are essential. Never switch to public read/write rules for convenience.
- This starter lets any signed-in user look up exact usernames and read public profile fields (display name and username). It does not expose email addresses in profiles.
- Messages are protected by Firebase Authentication and Firestore Security Rules, but they are **not end-to-end encrypted**. Firebase project administrators may have access to stored data.
- This is a starter project, not a fully audited production messaging service. Add abuse reporting, blocking, rate limits, email verification, password reset, moderation and automated security-rule tests before launching to a wider audience.
- Firebase usage limits and billing depend on your project and current Firebase plan.
